return {
  'OXY2DEV/markview.nvim',
  lazy = false,
}

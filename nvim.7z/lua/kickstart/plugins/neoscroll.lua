--https://github.com/karb94/neoscroll.nvim

return {
  "karb94/neoscroll.nvim",
  opts = {},
}
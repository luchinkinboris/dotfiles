return {
  'arnamak/stay-centered.nvim',
}

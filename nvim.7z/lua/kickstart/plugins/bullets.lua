return {
  'bullets-vim/bullets.vim',
}

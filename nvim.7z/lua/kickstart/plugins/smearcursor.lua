return {
  "sphamba/smear-cursor.nvim",
  opts = {},
}